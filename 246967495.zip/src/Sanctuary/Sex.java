package Sanctuary;

public enum Sex {
  MALE, FEMALE, UNKNOWN
}
