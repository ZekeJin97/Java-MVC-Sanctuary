package Sanctuary;

public enum Size {
  SMALL, MEDIUM, LARGE, UNKNOWN
}
